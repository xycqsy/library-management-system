# 部署配置说明

## 一、环境

| 项目 | 内容 |
|---|---|
| 操作系统 | CentOS Stream 10（Coughlan），内核 6.12.0-266.el10 |
| 数据库 | MongoDB 8.0.32 社区版（mongod / mongos / mongosh / mongoimport / mongodump） |
| Python | 3.12.14，pymongo 4.19.0、dnspython 2.9.2、python-dotenv 1.2.4 |
| 数据目录 | `/data/mongo`（三台一致，自定义目录） |
| 密钥文件 | `/etc/mongodb-keyfile`，1009 字节，权限 400，属主 mongod<br>md5：`621d44d4956cb6844536be9dda1de94b`（三台一致） |

## 二、三台主机与端口

| 主机名 | IP | 副本集 rs0 | 分片集群 |
|---|---|---|---|
| nosql01 | 192.168.121.129 | 27017 主节点（priority 2） | configsvr 27100、mongos 27200 |
| bogon | 192.168.121.130 | 27017 从节点 | shard1 27101 |
| nosql2 | 192.168.121.131 | 27017 从节点 | shard2 27102 |

两套部署同时运行，端口互不冲突。

## 三、配置文件

本目录下的 `mongod.conf.nosql01`、`mongod.conf.bogon`、`mongod.conf.nosql2` 为三台机器 `/etc/mongod.conf` 的原样备份，关键差异仅在主机名。

关键段落：

```yaml
net:
  port: 27017
  bindIp: 0.0.0.0
storage:
  dbPath: /data/mongo        # 自定义数据目录
security:
  keyFile: /etc/mongodb-keyfile
  authorization: enabled
replication:
  replSetName: rs0
```

## 四、启动方式

### 副本集（三台）

```bash
sudo systemctl start mongod
# 首次组建（在 129 上执行）
mongosh "mongodb://lib_admin:******@127.0.0.1:27017/?authSource=admin" --eval '
rs.initiate({_id:"rs0", members:[
  {_id:0, host:"192.168.121.129:27017", priority:2},
  {_id:1, host:"192.168.121.130:27017"},
  {_id:2, host:"192.168.121.131:27017"}]})'
```

### 分片集群（四个进程）

```bash
# 129：配置服务器
sudo -u mongod mongod --configsvr --replSet csrs --port 27100 \
  --dbpath /data/cfg --logpath /data/log/cfg.log --fork --bind_ip_all \
  --keyFile /etc/mongodb-keyfile
# 130 / 131：两个分片
sudo -u mongod mongod --shardsvr --replSet shard1 --port 27101 \
  --dbpath /data/shard1 --logpath /data/log/shard1.log --fork --bind_ip_all \
  --keyFile /etc/mongodb-keyfile
# 129：路由节点（需 CSRS 已初始化）
sudo -u mongod mongos --configdb csrs/192.168.121.129:27100 --port 27200 \
  --logpath /data/log/mongos.log --fork --bind_ip_all --keyFile /etc/mongodb-keyfile
```

## 五、账号

| 账号 | 角色 | 用途 |
|---|---|---|
| lib_admin | root@admin | 管理，副本集与分片集群均用此账号 |
| lib_writer | readWrite@smart_library | 业务读写 |
| lib_reader | read@smart_library | 只读 |

口令不在此文档中明文记录，见交付包内的 `.env.example`（占位）与实际 `.env`。

## 六、数据文件

`数据/` 目录包含：

- `导出/`：`category_stats.json`、`category_stats.csv`（任务七交付物），以及 `books.json`、`readers.json`、`borrow_logs.json` 三个业务集合
- `备份/`：`mongodump` 整库备份（7 个集合，含 GridFS 的 ebooks.files 与 ebooks.chunks）
- `gridfs_files/`：课程提供的原始电子书与封面

## 七、常用验证命令

```bash
# 副本集状态
mongosh "mongodb://lib_admin:******@127.0.0.1:27017/?authSource=admin&replicaSet=rs0" \
  --eval 'rs.status().members.map(m=>m.name+"="+m.stateStr)'

# 分片分布
mongosh "mongodb://lib_admin:******@127.0.0.1:27200/admin" --eval '
const c=db.getSiblingDB("config").collections.findOne({_id:"smart_library.borrow_logs"});
db.getSiblingDB("config").chunks.find({uuid:c.uuid}).count()'

# 各集合条数
mongosh "mongodb://lib_admin:******@127.0.0.1:27017/?authSource=admin&replicaSet=rs0" --eval '
const d=db.getSiblingDB("smart_library");
["books","readers","borrow_logs","category_stats","audit_logs"].forEach(n=>
  print(n+" = "+d[n].countDocuments()))'
```
