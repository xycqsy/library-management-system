"""统一数据库连接模块。

全程序只有这里创建 MongoClient，其余模块一律 from db import get_db，
避免在每个业务文件里重复写连接串（任务书要求：无硬编码连接串）。
"""
from pymongo import MongoClient
from pymongo.errors import PyMongoError

from config import Config

_client = None


def get_client() -> MongoClient:
    global _client
    if _client is None:
        _client = MongoClient(Config.uri(), serverSelectionTimeoutMS=Config.TIMEOUT_MS,
                              tz_aware=True)   # 取回的时间带时区，便于转本地时间展示
        _client.admin.command("ping")      # 连接失败时在这里立刻暴露
    return _client


def get_db():
    return get_client()[Config.DATABASE]


def close() -> None:
    global _client
    if _client is not None:
        _client.close()
        _client = None


def health() -> dict:
    """启动自检：服务器版本 + 各业务集合条数（GridFS 内部集合单独统计）。"""
    info = get_client().server_info()
    database = get_db()
    names = [n for n in database.list_collection_names() if "." not in n or n.startswith(("ebooks.files", "ebooks.chunks"))]
    business = {n: database[n].count_documents({}) for n in sorted(n for n in names if "." not in n)}
    gridfs_files = database["ebooks.files"].count_documents({}) if "ebooks.files" in names else 0
    return {
        "server": info.get("version"),
        "uri": Config.masked_uri(),
        "database": Config.DATABASE,
        "collections": business,
        "gridfs_files": gridfs_files,
    }


if __name__ == "__main__":
    try:
        import json
        print(json.dumps(health(), ensure_ascii=False, indent=2))
    except PyMongoError as exc:
        print(f"连接失败: {exc}")
    finally:
        close()
