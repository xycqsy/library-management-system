"""借阅：登记、归还、逾期查询。

借阅登记同时改两个集合（写流水 + 扣库存），因此使用单文档原子操作配合事务语义：
库存扣减用 $inc 并在条件里带 stock>0，保证不会超借。
"""
from datetime import datetime, timezone

from pymongo.errors import PyMongoError

from db import get_db

LOGS = "borrow_logs"
BOOKS = "books"


def borrow(card_no: str, isbn: str, days: int = 30) -> dict:
    """登记借阅：校验读者与库存，写流水并扣减库存。"""
    db = get_db()
    reader = db["readers"].find_one({"card_no": card_no}, {"_id": 0, "name": 1})
    if not reader:
        raise ValueError(f"读者不存在: {card_no}")

    # 条件更新：只有 stock > 0 才会扣减，天然防超借
    res = db[BOOKS].update_one({"isbn": isbn, "stock": {"$gt": 0}}, {"$inc": {"stock": -1, "borrow_count": 1}})
    if res.modified_count == 0:
        raise ValueError(f"库存不足或图书不存在: {isbn}")

    log = {
        "reader_card": card_no,
        "book_isbn": isbn,
        "borrow_date": datetime.now(timezone.utc),
        "status": "借出",
        "duration_days": int(days),
    }
    db[LOGS].insert_one(log)
    stock = db[BOOKS].find_one({"isbn": isbn}, {"_id": 0, "stock": 1})["stock"]
    return {"reader": reader["name"], "isbn": isbn, "stock_left": stock}


def give_back(isbn: str, card_no: str) -> dict:
    """归还：把最早一条「借出」流水改为「已归还」，并回补库存。"""
    db = get_db()
    log = db[LOGS].find_one_and_update(
        {"book_isbn": isbn, "reader_card": card_no, "status": "借出"},
        {"$set": {"status": "已归还", "return_date": datetime.now(timezone.utc)}},
        sort=[("borrow_date", 1)],
    )
    if not log:
        raise ValueError(f"没有找到该读者对该书的在借记录: {card_no} / {isbn}")
    db[BOOKS].update_one({"isbn": isbn}, {"$inc": {"stock": 1}})
    return {"isbn": isbn, "card_no": card_no, "log_id": str(log["_id"])}


def overdue(limit: int = 10) -> dict:
    db = get_db()
    flt = {"status": "逾期"}
    return {"total": db[LOGS].count_documents(flt),
            "rows": list(db[LOGS].find(flt, {"_id": 0}).sort([("borrow_date", 1)]).limit(limit))}


def active_by_reader(card_no: str) -> list:
    return list(get_db()[LOGS].find({"reader_card": card_no, "status": "借出"}, {"_id": 0})
                .sort([("borrow_date", -1)]))
