"""配置读取。所有连接参数来自 .env 或环境变量，代码中不出现任何地址与口令。"""
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


class Config:
    HOST = os.getenv("MONGODB_HOST", "127.0.0.1")
    PORT = int(os.getenv("MONGODB_PORT", "27017"))
    DATABASE = os.getenv("MONGODB_DATABASE", "smart_library")
    USERNAME = os.getenv("MONGODB_USERNAME", "")
    PASSWORD = os.getenv("MONGODB_PASSWORD", "")
    AUTH_SOURCE = os.getenv("MONGODB_AUTH_SOURCE", "admin")
    TIMEOUT_MS = int(os.getenv("MONGODB_TIMEOUT_MS", "5000"))
    # 单机与副本集两种部署方式：配了完整 URI 就优先用它
    URI_OVERRIDE = os.getenv("MONGODB_URI", "")

    DATA_DIR = BASE_DIR / os.getenv("DATA_DIR", "data")
    DOWNLOAD_DIR = BASE_DIR / os.getenv("DOWNLOAD_DIR", "downloads")

    @classmethod
    def uri(cls) -> str:
        """完整连接串优先；否则由 host/port/账号拼出来。"""
        if cls.URI_OVERRIDE:
            return cls.URI_OVERRIDE
        auth = f"{cls.USERNAME}:{cls.PASSWORD}@" if cls.USERNAME else ""
        query = f"?authSource={cls.AUTH_SOURCE}" if cls.USERNAME else ""
        return f"mongodb://{auth}{cls.HOST}:{cls.PORT}/{query}"

    @classmethod
    def masked_uri(cls) -> str:
        """用于打印的连接串，隐去口令。

        兼容两种来源：完整连接串（口令在 URI 内）与分散配置（口令在 PASSWORD）。
        统一用正则把 //user:password@ 中的口令替换为 ***。
        """
        import re
        u = cls.uri()
        u = re.sub(r"(mongodb(?:\+srv)?://[^:/@]+:)[^@]*@", r"\1***@", u)
        if cls.PASSWORD and cls.PASSWORD in u:
            u = u.replace(cls.PASSWORD, "***")
        return u
