"""操作日志：写入固定集合 audit_logs（1MB / 最多 1000 条，自动淘汰最老记录）。

固定集合不支持修改与删除，只能整条插入，正好符合"流水账"的语义。
actions 必须落在 collMod 校验器声明的枚举内：创建/更新/删除/导出/上传/下载。
"""
import functools
import time
from datetime import datetime, timezone

from config import Config
from db import get_db

ACTIONS = ("创建", "更新", "删除", "导出", "上传", "下载")


def write_log(action: str, target: str, result: str = "成功", detail: str = "", cost_ms: int = 0) -> None:
    if action not in ACTIONS:
        raise ValueError(f"未声明的操作类型: {action}")
    get_db()["audit_logs"].insert_one({
        "ts": datetime.now(timezone.utc),
        "action": action,
        "target": str(target)[:120],
        "operator": Config.USERNAME or "unknown",
        "result": result,
        "detail": str(detail)[:200],
        "cost_ms": int(cost_ms),
    })


def audited(action: str, target):
    """装饰器：记录成功与失败，并统计耗时。

    target 可以是字符串，也可以是接收被装饰函数参数的函数，
    用于把"对哪个对象操作"写进日志。
    """
    if not isinstance(target, str):
        target_of = target
    else:
        target_of = lambda *a, **k: target

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            started = time.perf_counter()
            status, detail = "成功", ""
            try:
                return func(*args, **kwargs)
            except Exception as exc:            # 失败也要留痕
                status, detail = "失败", str(exc)
                raise
            finally:
                cost = (time.perf_counter() - started) * 1000
                try:
                    write_log(action, target_of(*args, **kwargs), status, detail, cost)
                except Exception:
                    pass                        # 日志失败不能盖掉业务异常
        return wrapper
    return decorator


def recent(limit: int = 100) -> list:
    """按写入顺序倒序取最近 N 条。

    固定集合按写入顺序存储，用 $natural:-1 直接从尾部倒读，
    不需要在 ts 上建索引，也不会扫描全集合。
    """
    db = get_db()
    return list(db["audit_logs"].find().sort([("$natural", -1)]).limit(limit))


def summary() -> dict:
    """各类操作与成功/失败统计，供报告引用。"""
    db = get_db()
    by_action = list(db["audit_logs"].aggregate([
        {"$group": {"_id": {"a": "$action", "r": "$result"}, "n": {"$sum": 1}}},
        {"$sort": {"_id.a": 1}},
    ]))
    return {
        "total": db["audit_logs"].count_documents({}),
        "by_action": [{"action": x["_id"]["a"], "result": x["_id"]["r"], "n": x["n"]} for x in by_action],
    }
