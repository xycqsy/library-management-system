"""图书：检索、分页排序、增删改。"""
from db import get_db

COLLECTION = "books"
PROJECTION = {"_id": 0, "isbn": 1, "title": 1, "author": 1,
              "category": 1, "price": 1, "rating": 1, "stock": 1}


def search_by_category_price(category: str = None, price_min: float = None,
                             price_max: float = None, page: int = 1, size: int = 5) -> dict:
    """类别与价格区间组合筛选，带分页与排序。"""
    flt = {}
    if category:
        flt["category"] = category
    if price_min is not None or price_max is not None:
        rng = {}
        if price_min is not None:
            rng["$gte"] = price_min
        if price_max is not None:
            rng["$lte"] = price_max
        flt["price"] = rng
    coll = get_db()[COLLECTION]
    total = coll.count_documents(flt)
    rows = list(coll.find(flt, PROJECTION)
                .sort([("price", 1), ("title", 1)])
                .skip(max(page - 1, 0) * size).limit(size))
    return {"filter": flt, "total": total, "page": page, "size": size, "rows": rows}


def search_by_title(keyword: str, limit: int = 10) -> dict:
    """书名模糊检索。前缀匹配可命中 idx_title，中间匹配只能扫全集合。"""
    import re
    coll = get_db()[COLLECTION]
    flt = {"title": re.compile(re.escape(keyword))}
    return {"filter": f"title ~ /{keyword}/", "total": coll.count_documents(flt),
            "rows": list(coll.find(flt, PROJECTION).limit(limit))}


def search_missing_tags() -> dict:
    """数据质量核查：真正缺失该字段的文档（区别于字段值为 null）。"""
    coll = get_db()[COLLECTION]
    flt = {"tags": {"$exists": False}}
    return {"filter": flt, "total": coll.count_documents(flt),
            "rows": list(coll.find(flt, {"_id": 0, "isbn": 1, "title": 1, "category": 1}))}


def top_rated(limit: int = 10) -> list:
    """评分排序取前 N，仅返回书名、作者、评分。"""
    return list(get_db()[COLLECTION].find({}, {"_id": 0, "title": 1, "author": 1, "rating": 1})
                .sort([("rating", -1), ("title", 1)]).limit(limit))


def get_by_isbn(isbn: str):
    return get_db()[COLLECTION].find_one({"isbn": isbn}, {"_id": 0})


def add_book(doc: dict) -> str:
    """新增图书。字段类型由集合校验器把关，类型不对会直接抛 WriteError。"""
    get_db()[COLLECTION].insert_one(doc)
    return doc["isbn"]


def delete_book(isbn: str) -> int:
    return get_db()[COLLECTION].delete_one({"isbn": isbn}).deleted_count


def update_stock(isbn: str, delta: int) -> int:
    res = get_db()[COLLECTION].update_one({"isbn": isbn}, {"$inc": {"stock": delta}})
    return res.modified_count
