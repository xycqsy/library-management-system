"""脚本化演示：把各项功能的真实输出打印出来，用于生成过程记录图。

用法： python demo.py search|upload|download|list|audit|all
"""
import json
import sys

import audit
import book_manager as bm
import db
import gridfs_manager as gfs
import reader_manager as rm
import stat_manager as sm
from config import Config
from main import MANIFEST


def p(title: str, obj) -> None:
    print(f"\n===== {title} =====")
    if isinstance(obj, str):
        print(obj)
    else:
        print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))


def _dw(s) -> int:
    """终端显示宽度：中日韩全角字符按 2 列计算。"""
    import unicodedata
    return sum(2 if unicodedata.east_asian_width(c) in ("W", "F") else 1 for c in str(s))


def _pad(s, width: int) -> str:
    s = str(s)
    return s + " " * max(0, width - _dw(s))


def as_table(rows, cols):
    widths = {c: max([_dw(c)] + [_dw(r.get(c, "")) for r in rows]) for c in cols}
    head = "  ".join(_pad(c, widths[c]) for c in cols)
    print(head)
    print("-" * _dw(head))
    for r in rows:
        print("  ".join(_pad(r.get(c, ""), widths[c]) for c in cols))


def cmd_search():
    info = db.health()
    print(f"已连接 {info['uri']}  服务端 {info['server']}  库 {info['database']}")
    print(f"集合条数：{info['collections']}")

    r = bm.search_by_category_price("计算机", 50, 100, page=1, size=3)
    print(f"\n===== 检索一：类别=计算机 且 价格 50~100（共 {r['total']} 条，第 {r['page']} 页）=====")
    as_table(r["rows"], ["title", "category", "price", "rating", "stock"])

    t = bm.search_by_title("计算机")
    print(f"\n===== 检索二：书名含「计算机」（共 {t['total']} 条）=====")
    as_table(t["rows"], ["title", "author", "price"])

    m = bm.search_missing_tags()
    print(f"\n===== 检索三：缺少 tags 字段（共 {m['total']} 条，数据质量核查）=====")
    as_table(m["rows"], ["isbn", "title", "category"])

    print("\n===== 检索四：评分 Top5 =====")
    as_table(bm.top_rated(5), ["title", "author", "rating"])


def cmd_stats():
    print("===== 统计一：分类统计（藏书量 / 平均价格 / 平均评分）=====")
    as_table(sm.category_stats(), ["category", "藏书量", "平均价格", "平均评分"])

    print("\n===== 统计二：学院借阅 Top5（并列按学院名兜底排序）=====")
    as_table(sm.college_top(), ["学院", "借阅总量"])

    trend = sm.monthly_trend()
    print(f"\n===== 统计三：年月借阅趋势（共 {len(trend)} 个月，列出首尾各 3 个月）=====")
    as_table(trend[:3] + trend[-3:], ["年月", "借阅量"])

    print("\n===== 统计四：借阅排行 Top5（含馆藏位置）=====")
    rows = [{"title": x["title"], "borrow_count": x["borrow_count"],
             "楼层": x["location"]["floor"], "架位": x["location"]["shelf"]} for x in sm.top_borrowed(5)]
    as_table(rows, ["title", "borrow_count", "楼层", "架位"])

    print("\n===== 统计五：分类统计落库 =====")
    p("写入 category_stats", sm.save_category_stats())


def cmd_upload():
    removed = gfs.purge()
    print(f"清理历史文件 {removed} 个，开始上传 {len(MANIFEST)} 个文件")
    rows = gfs.upload_dir(str(Config.DATA_DIR / "gridfs_files"), MANIFEST)
    print("\n===== GridFS 上传结果 =====")
    out = [{"文件名": r["filename"], "类型": r["type"], "ISBN": r["isbn"],
            "字节数": r["bytes"], "SHA256": r["sha256"][:16] + "…"} for r in rows]
    as_table(out, ["文件名", "类型", "ISBN", "字节数", "SHA256"])
    print(f"\n共上传 {len(rows)} 个文件，合计 {sum(r['bytes'] for r in rows)} 字节")


def cmd_download():
    for keyword in ["深入理解计算机系统", "算法图解"]:
        r = gfs.download_by_title(keyword)
        print(f"\n===== 下载并校验：《{r['book']}》 =====")
        print(f"  关联 ISBN     : {r['isbn']}")
        print(f"  文件名        : {r['file']}")
        print(f"  保存到        : {r['saved_to']}")
        print(f"  上传字节数    : {r['upload_bytes']}")
        print(f"  下载字节数    : {r['download_bytes']}   -> {'一致 ✓' if r['bytes_ok'] else '不一致 ✗'}")
        print(f"  上传 SHA256   : {r['upload_sha256']}")
        print(f"  下载 SHA256   : {r['download_sha256']}")
        print(f"  摘要校验      : {'一致 ✓' if r['sha256_ok'] else '不一致 ✗'}")


def cmd_list():
    rows = gfs.list_files()
    print(f"\n===== GridFS 文件清单（共 {len(rows)} 个）=====")
    as_table(rows, ["filename", "type", "isbn", "bytes", "uploaded_at"])
    verify = gfs.verify_all()
    print("\n===== 全量完整性复核 =====")
    as_table(verify, ["filename", "bytes", "expect_bytes", "bytes_ok", "sha256_ok"])
    ok = all(v["bytes_ok"] and v["sha256_ok"] for v in verify)
    print(f"\n结论：{len(verify)} 个文件{'全部' if ok else '存在'}校验通过{' ✓' if ok else ' ✗'}")


def cmd_audit():
    rows = audit.recent(8)
    print("===== 最近 8 条操作日志（$natural 倒序，取尾部）=====")
    out = [{"时间": r["ts"].astimezone().strftime("%H:%M:%S"), "操作": r["action"],
            "对象": r["target"][:34], "结果": r["result"], "耗时ms": r["cost_ms"]} for r in rows]
    as_table(out, ["时间", "操作", "对象", "结果", "耗时ms"])
    print("\n===== 日志统计 =====")
    s = audit.summary()
    print(f"  日志总数: {s['total']}")
    for x in s["by_action"]:
        print(f"  {x['action']} / {x['result']}: {x['n']} 条")


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "all"
    steps = {
        "search": cmd_search, "stats": cmd_stats, "upload": cmd_upload,
        "download": cmd_download, "list": cmd_list, "audit": cmd_audit,
    }
    try:
        if cmd == "all":
            for f in steps.values():
                f()
        elif cmd in steps:
            steps[cmd]()
        else:
            print(f"未知命令: {cmd}")
            return 2
    finally:
        db.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
