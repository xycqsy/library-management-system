"""智慧图书馆数字资源平台 —— 命令行主程序。

菜单只负责输入与展示，数据库操作全部下沉到各业务模块。
"""
import json
import sys

from pymongo.errors import PyMongoError

import audit
import book_manager as bm
import borrow_manager as borm
import db
import gridfs_manager as gfs
import reader_manager as rm
import stat_manager as sm
from config import Config

MENU = """
智慧图书馆数字资源平台 · 功能菜单
==========================================================================
  1  系统自检（连接状态 + 各集合条数）
  2  图书检索：类别 + 价格区间（分页）
  3  图书模糊检索：书名关键字
  4  数据质量核查：缺少 tags 字段的图书
  5  评分排行 Top10（仅书名/作者/评分）
  6  读者查询：按借阅证号
  7  借阅登记（扣减库存）
  8  逾期记录查询
  9  分类统计：藏书量 / 平均价格 / 平均评分
 10  学院借阅总量 Top5
 11  年月借阅趋势
 12  借阅排行 Top10（含馆藏位置）
 13  分类统计落库（写入 category_stats）
 14  导出统计结果（Extended JSON）
 15  GridFS 上传电子书与封面
 16  GridFS 按书名下载并做完整性校验
 17  GridFS 文件清单与全量复核
 18  最近操作日志（固定集合，最多 1000 条）
 19  操作日志统计
  0  退出
==========================================================================
"""

# 电子书与封面：文件名 -> (ISBN, 类型)，取自 files_manifest.txt
MANIFEST = {
    "ebook_1.pdf": ("9787115428028", "ebook"),
    "ebook_2.pdf": ("9787121362726", "ebook"),
    "ebook_3.pdf": ("9787115546081", "ebook"),
    "cover_1.png": ("9787115428028", "cover"),
    "cover_2.png": ("9787121362726", "cover"),
    "cover_3.png": ("9787115546081", "cover"),
}


def show(title, data):
    print(f"\n── {title} ──")
    print(json.dumps(data, ensure_ascii=False, indent=2) if not isinstance(data, str) else data)


def ask(prompt, cast=str, default=None):
    raw = input(prompt).strip()
    if not raw:
        return default
    return cast(raw)


def menu_loop():
    while True:
        print(MENU)
        choice = input("请输入功能编号: ").strip()

        try:
            if choice == "0":
                print("再见。")
                break
            elif choice == "1":
                show("系统自检", db.health())
            elif choice == "2":
                cat = ask("类别（直接回车=全部）: ", default=None)
                lo = ask("最低价（回车=不限）: ", float, None)
                hi = ask("最高价（回车=不限）: ", float, None)
                page = ask("页码（回车=1）: ", int, 1)
                show("类别+价格区间检索", bm.search_by_category_price(cat, lo, hi, page))
            elif choice == "3":
                kw = ask("书名关键字: ")
                show("模糊检索", bm.search_by_title(kw))
            elif choice == "4":
                show("缺少 tags 的图书", bm.search_missing_tags())
            elif choice == "5":
                show("评分 Top10", bm.top_rated())
            elif choice == "6":
                show("读者查询", rm.find_by_card(ask("借阅证号: ")))
            elif choice == "7":
                card = ask("借阅证号: ")
                isbn = ask("ISBN: ")
                show("借阅登记", borm.borrow(card, isbn))
            elif choice == "8":
                show("逾期记录", borm.overdue())
            elif choice == "9":
                show("分类统计", sm.category_stats())
            elif choice == "10":
                show("学院借阅 Top5", sm.college_top())
            elif choice == "11":
                show("年月借阅趋势", sm.monthly_trend())
            elif choice == "12":
                show("借阅排行 Top10", sm.top_borrowed())
            elif choice == "13":
                show("分类统计落库", sm.save_category_stats())
            elif choice == "14":
                path = sm.export_all()
                audit.write_log("导出", str(path))
                show("导出完成", str(path))
            elif choice == "15":
                rows = gfs.upload_dir(str(Config.DATA_DIR / "gridfs_files"), MANIFEST)
                show(f"GridFS 上传完成（{len(rows)} 个文件）", rows)
            elif choice == "16":
                show("按书名下载并校验", gfs.download_by_title(ask("书名关键字: ")))
            elif choice == "17":
                show("GridFS 文件清单", gfs.list_files())
                show("完整性复核", gfs.verify_all())
            elif choice == "18":
                show("最近操作日志", audit.recent(10))
            elif choice == "19":
                show("操作日志统计", audit.summary())
            else:
                print("无效编号，请重新输入。")
        except (ValueError, KeyError) as exc:
            print(f"✗ 操作失败：{exc}")
        except PyMongoError as exc:
            print(f"✗ 数据库错误：{exc}")


def main() -> int:
    try:
        info = db.health()
    except PyMongoError as exc:
        print(f"无法连接数据库：{exc}")
        print(f"当前连接串：{Config.masked_uri()}")
        return 1
    print(f"已连接 {info['uri']}  服务端 {info['server']}  库 {info['database']}")
    counts = "  ".join(f"{k}={v}" for k, v in info["collections"].items())
    print(f"集合条数：{counts}   GridFS 文件：{info['gridfs_files']}")
    try:
        menu_loop()
    finally:
        db.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
