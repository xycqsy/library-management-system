"""维护脚本：重建固定集合与 GridFS 桶，供演示前重置状态。

固定集合不支持删除单条文档，重置只能整集合 drop 后按原参数重建，
校验器也必须一并重新挂上，否则会丢掉 audit_logs 的字段约束。
"""
import gridfs

import db
import gridfs_manager as gfs

AUDIT_VALIDATOR = {"$jsonSchema": {
    "bsonType": "object",
    "required": ["ts", "action", "operator", "result"],
    "properties": {
        "ts": {"bsonType": "date"},
        "action": {"bsonType": "string",
                   "enum": ["创建", "更新", "删除", "导出", "上传", "下载"]},
        "target": {"bsonType": "string"},
        "operator": {"bsonType": "string"},
        "result": {"bsonType": "string", "enum": ["成功", "失败"]},
        "detail": {"bsonType": "string"},
        "cost_ms": {"bsonType": "int"},
    },
}}


def reset_audit_logs() -> dict:
    database = db.get_db()
    database["audit_logs"].drop()
    database.create_collection(
        "audit_logs", capped=True, size=1048576, max=1000,
        validator=AUDIT_VALIDATOR, validationLevel="strict", validationAction="error",
    )
    info = database.command("collStats", "audit_logs")
    return {"capped": info["capped"], "max": info["max"], "maxSize": info["maxSize"],
            "count": database["audit_logs"].count_documents({})}


def reset_gridfs() -> int:
    return gfs.purge()


if __name__ == "__main__":
    try:
        print("重置 audit_logs ->", reset_audit_logs())
        print("清理 GridFS    ->", reset_gridfs(), "个文件")
    finally:
        db.close()
