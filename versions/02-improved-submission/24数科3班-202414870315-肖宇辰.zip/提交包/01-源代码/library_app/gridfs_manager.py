"""GridFS：电子书与封面图的上传、按书名下载、完整性校验与清单。

元数据写入 GridFS 文件的 metadata 字段：
  isbn          关联 books.isbn
  type          ebook / cover
  original_name 原始文件名
  sha256        上传时的内容摘要，下载后逐字节复核
  uploader      上传账号
"""
import hashlib
from datetime import datetime, timezone
from pathlib import Path

import gridfs

from config import Config
from db import get_db
from audit import audited, write_log

BUCKET = "ebooks"


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _fs():
    return gridfs.GridFS(get_db(), collection=BUCKET)


@audited("上传", lambda path, isbn, ftype: f"{isbn}/{Path(path).name}")
def upload_file(path: str, isbn: str, ftype: str = "ebook") -> dict:
    data = Path(path).read_bytes()
    digest = _sha256(data)
    file_id = _fs().put(
        data,
        filename=Path(path).name,
        metadata={
            "isbn": isbn,
            "type": ftype,
            "original_name": Path(path).name,
            "sha256": digest,
            "bytes": len(data),
            "uploader": Config.USERNAME or "unknown",
            "uploaded_at": datetime.now(timezone.utc),
        },
    )
    return {"file_id": str(file_id), "filename": Path(path).name, "isbn": isbn,
            "type": ftype, "bytes": len(data), "sha256": digest}


def upload_dir(directory: str, manifest: dict) -> list:
    """按清单批量上传：manifest 形如 {"ebook_1.pdf": (isbn, "ebook"), ...}"""
    results = []
    for name, (isbn, ftype) in manifest.items():
        p = Path(directory) / name
        if p.exists():
            results.append(upload_file(str(p), isbn, ftype))
    return results


def purge() -> int:
    """清空 GridFS 桶，便于重复演示（只影响 ebooks 桶，不碰业务集合）。"""
    fs = _fs()
    n = 0
    for f in list(fs.find({})):
        fs.delete(f._id)
        n += 1
    return n


def list_files() -> list:
    rows = []
    for f in _fs().find({}).sort([("uploadDate", 1)]):
        md = f.metadata or {}
        rows.append({
            "filename": f.filename,
            "bytes": md.get("bytes", f.length),
            "isbn": md.get("isbn"),
            "type": md.get("type"),
            "uploaded_at": (md.get("uploaded_at") or f.upload_date).astimezone().strftime("%Y-%m-%d %H:%M:%S"),
            "sha256": (md.get("sha256") or "")[:12] + "…",
        })
    return rows


@audited("下载", lambda title, dest_dir=None: f"book:{title}")
def download_by_title(title: str, dest_dir: str = None) -> dict:
    """按书名找到图书 -> 取 ebook_name -> 从 GridFS 下载 -> 字节数与 SHA256 双校验。"""
    db = get_db()
    book = db["books"].find_one({"title": {"$regex": title, "$options": "i"}},
                                {"_id": 0, "title": 1, "isbn": 1, "ebook_name": 1})
    if not book:
        raise ValueError(f"没有找到书名包含「{title}」的图书")
    if not book.get("ebook_name"):
        raise ValueError(f"《{book['title']}》没有关联电子书")

    fs = _fs()
    stored = fs.find_one({"filename": book["ebook_name"]})
    if stored is None:
        raise ValueError(f"GridFS 中不存在文件 {book['ebook_name']}")

    data = stored.read()
    out_dir = Path(dest_dir) if dest_dir else Config.DOWNLOAD_DIR
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / book["ebook_name"]
    out_path.write_bytes(data)

    md = stored.metadata or {}
    expect_bytes = md.get("bytes", stored.length)
    expect_sha = md.get("sha256")
    got_sha = _sha256(data)

    return {
        "book": book["title"],
        "isbn": book["isbn"],
        "file": book["ebook_name"],
        "saved_to": str(out_path),
        "upload_bytes": expect_bytes,
        "download_bytes": len(data),
        "bytes_ok": expect_bytes == len(data),
        "upload_sha256": expect_sha,
        "download_sha256": got_sha,
        "sha256_ok": (expect_sha == got_sha),
    }


def verify_all() -> list:
    """逐个文件复核：重新读取并比对长度与摘要。"""
    fs = _fs()
    rows = []
    for f in fs.find({}):
        md = f.metadata or {}
        data = f.read()
        rows.append({
            "filename": f.filename,
            "bytes": len(data),
            "expect_bytes": md.get("bytes", f.length),
            "bytes_ok": len(data) == md.get("bytes", f.length),
            "sha256_ok": _sha256(data) == md.get("sha256"),
        })
    return rows
