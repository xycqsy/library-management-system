"""读者：按证号查询、按学院查询、学院与等级分布。"""
from db import get_db

COLLECTION = "readers"
PROJECTION = {"_id": 0, "card_no": 1, "name": 1, "college": 1,
              "level": 1, "email": 1, "phone": 1}


def find_by_card(card_no: str):
    return get_db()[COLLECTION].find_one({"card_no": card_no}, PROJECTION)


def find_by_college(college: str, limit: int = 10) -> list:
    return list(get_db()[COLLECTION].find({"college": college}, PROJECTION).limit(limit))


def college_distribution() -> list:
    return list(get_db()[COLLECTION].aggregate([
        {"$group": {"_id": "$college", "人数": {"$sum": 1}}},
        {"$sort": {"人数": -1, "_id": 1}},
        {"$project": {"_id": 0, "学院": "$_id", "人数": 1}},
    ]))


def level_distribution() -> list:
    return list(get_db()[COLLECTION].aggregate([
        {"$group": {"_id": "$level", "人数": {"$sum": 1}}},
        {"$sort": {"_id": 1}},
        {"$project": {"_id": 0, "等级": "$_id", "人数": 1}},
    ]))


def missing_email_count() -> int:
    return get_db()[COLLECTION].count_documents({"email": None})
