"""统计：分类、学院、年月趋势、借阅排行、落库与导出。"""
import json
from pathlib import Path

from bson import json_util

from config import Config
from db import get_db


def category_stats() -> list:
    """按类别统计藏书量、平均价格、平均评分。

    舍入统一用 $round（银行家舍入），避免与 JS/Excel 的四舍五入产生差异。
    """
    return list(get_db()["books"].aggregate([
        {"$group": {"_id": "$category",
                    "藏书量": {"$sum": 1},
                    "平均价格": {"$avg": "$price"},
                    "平均评分": {"$avg": "$rating"}}},
        {"$project": {"_id": 0, "category": "$_id", "藏书量": 1,
                      "平均价格": {"$round": ["$平均价格", 2]},
                      "平均评分": {"$round": ["$平均评分", 2]}}},
        {"$sort": {"藏书量": -1, "category": 1}},
    ]))


def college_top(limit: int = 5) -> list:
    """各学院借阅总量 Top N。

    借阅总量存在大量并列，必须加第二排序键，否则每次 $limit 取到的人不一样。
    """
    return list(get_db()["borrow_logs"].aggregate([
        {"$group": {"_id": "$reader_card", "次数": {"$sum": 1}}},
        {"$lookup": {"from": "readers", "localField": "_id", "foreignField": "card_no", "as": "r"}},
        {"$unwind": "$r"},
        {"$group": {"_id": "$r.college", "借阅总量": {"$sum": "$次数"}}},
        {"$sort": {"借阅总量": -1, "_id": 1}},
        {"$limit": limit},
        {"$project": {"_id": 0, "学院": "$_id", "借阅总量": 1}},
    ]))


def monthly_trend() -> list:
    """按年月统计借阅量，输出 YYYY-MM 可读标签（东八区）。"""
    return list(get_db()["borrow_logs"].aggregate([
        {"$group": {"_id": {"$dateToString": {"format": "%Y-%m", "date": "$borrow_date",
                                              "timezone": "Asia/Shanghai"}},
                    "借阅量": {"$sum": 1}}},
        {"$sort": {"_id": 1}},
        {"$project": {"_id": 0, "年月": "$_id", "借阅量": 1}},
    ]))


def top_borrowed(limit: int = 10) -> list:
    """借阅次数最多的图书，并关联出馆藏位置。"""
    return list(get_db()["books"].find(
        {}, {"_id": 0, "isbn": 1, "title": 1, "borrow_count": 1,
             "location.floor": 1, "location.shelf": 1})
        .sort([("borrow_count", -1), ("isbn", 1)]).limit(limit))


def save_category_stats() -> dict:
    """把分类统计结果写入集合 category_stats，供后续直接查询。"""
    db = get_db()
    db["books"].aggregate([
        {"$group": {"_id": "$category", "藏书量": {"$sum": 1},
                    "平均价格": {"$avg": "$price"}, "平均评分": {"$avg": "$rating"}}},
        {"$project": {"_id": 0, "category": "$_id", "藏书量": 1,
                      "平均价格": {"$round": ["$平均价格", 2]},
                      "平均评分": {"$round": ["$平均评分", 2]}}},
        {"$sort": {"藏书量": -1}},
        {"$out": "category_stats"},
    ])
    return {"collection": "category_stats", "count": db["category_stats"].count_documents({})}


def export_all(basename: str = "stats_export") -> Path:
    """把统计结果导出为 MongoDB Extended JSON，作为交付物。"""
    Config.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    payload = {
        "exported_at": __import__("datetime").datetime.now().isoformat(timespec="seconds"),
        "category_stats": list(get_db()["category_stats"].find({}, {"_id": 0})),
        "college_top": college_top(),
        "monthly_trend": monthly_trend(),
        "top_borrowed": top_borrowed(),
    }
    path = Config.DOWNLOAD_DIR / f"{basename}.json"
    path.write_text(json_util.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
    return path
